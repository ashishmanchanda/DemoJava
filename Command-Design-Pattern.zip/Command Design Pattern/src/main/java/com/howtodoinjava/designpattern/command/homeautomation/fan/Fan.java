package com.howtodoinjava.designpattern.command.homeautomation.fan;

public class Fan {
	void start() {
		System.out.println("Fan Started..");

	}

	 void stop() {
		System.out.println("Fan stopped..");

	}
}
